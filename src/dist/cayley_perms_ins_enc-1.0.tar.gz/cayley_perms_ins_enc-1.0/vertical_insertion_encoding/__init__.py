""" Package for insertion encoding. """

from .vert_config import Configuration, Word
from .check_regular_vert import (
    regular_vertical_insertion_encoding,
    check_if_type,
)
